package view;

public enum View {
	MAIN,					// 기본화면
	ADMIN,
	LOGIN,
	BOOK_MAIN,
	BOOK_LIST,
	BOOK_DETAIL,
	HOLD_MAIN,
	BOOK_INSERT,
	BOOK_UPDATE,
	BOOK_DELETE,
	HOLD_INSERT,
	HOLD_DELETE,
	HOLD_LIST
}
