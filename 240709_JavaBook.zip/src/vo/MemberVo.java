package vo;

import lombok.Data;

@Data
public class MemberVo {

    private int mem_no;
    private String mem_id;
    private String mem_pass;
    private String mem_name;
    private String delyn;
    private String join_date;
}
